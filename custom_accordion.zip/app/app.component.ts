import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {

  title = 'accordion';
  public currentid;
  public hidden: any = 'HIDDEN';
  public visible: any = 'VISIBLE';
  public issuesExpanded = [];
  public issuesHidden = [];

  public accordianData = [
    {
      name: 'Issue1',
      content: 'Object Name : Not Applicable - Not Applicable',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',
    },
    {
      name: 'Issue2',
      content: 'Test1',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',
    },
    {
      name: 'Issue3',
      content: 'Test2',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',
    },
    {
      name: 'Issue4',
      content: 'Object Name : Not Applicable - Not Applicable',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',
    },
    {
      name: 'Issue5',
      content: 'Test3',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',
    },
    {
      name: 'Issue6',
      content: 'Test4',
      text1: 'SCv2000 FC8G 65459 - EN65459',
      text2: 'last Check 80567',

    }
  ];

  public toggle(index) {
    this.issuesExpanded = [];
    if (this.accordianData && this.accordianData.length > 0) {
      const issuesLength = this.accordianData.length;
      this.issuesExpanded = Array(issuesLength).fill(false);
    }
    if (this.issuesExpanded[index] || this.currentid === index) {
      this.issuesExpanded[index] = false;
      this.currentid = '';

    } else {
      this.issuesExpanded[index] = true;
      this.currentid = index;
    }
  }

  public showStatus(index) {
    if (this.issuesHidden[index]) {
      this.issuesHidden[index] = false;

    } else {
      this.issuesHidden[index] = true;
    }
  }

  ngOnInit() {
    if (this.accordianData && this.accordianData.length > 0) {
      const issuesStatusLength = this.accordianData.length;
      this.issuesHidden = Array(issuesStatusLength).fill(false);
    }

  }
}
