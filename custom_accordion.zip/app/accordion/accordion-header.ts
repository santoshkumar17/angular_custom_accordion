import { Component, EventEmitter, Input, Output } from '@angular/core';


@Component({
    selector: 'accordion-header',
    styleUrls: ['accordion.css'],
    template: `
    <div (click)='toggle()'>
    <div class="col-xs-12 col-2 accordion-hdr data-cell-space">
      <ng-content></ng-content>
    </div>
  </div>
  `
})

export class AccordionHeader {
    @Output()
    public openChange: EventEmitter<any> = new EventEmitter();

    private _open: boolean = false;
    public get open() {
        return this._open;
    }
    private toggle(i) {
        this._open = !this._open;
        this.openChange.emit(this._open);
    }
    private get caretDirection(): string {
        return this.open ? 'down' : 'right';
    }
}

