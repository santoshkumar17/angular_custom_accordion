import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ClarityModule } from '@clr/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AccordionContainer } from './accordion/accordion-container';
import { AccordionHeader } from './accordion/accordion-header';
import { AccordionContent } from './accordion/accordion-content';

@NgModule({
  declarations: [
    AppComponent, AccordionContainer, AccordionHeader, AccordionContent
  ],
  imports: [
    BrowserModule,
    ClarityModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
