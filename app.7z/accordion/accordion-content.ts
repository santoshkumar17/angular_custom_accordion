import { Component } from '@angular/core';


@Component({
  selector: 'accordion-content',
  styleUrls: ['accordion.css'],
  template: `
  <div class="accordion-content">
  <ng-content></ng-content>
 </div>
  `
})


export class AccordionContent {
  open: boolean;
}
