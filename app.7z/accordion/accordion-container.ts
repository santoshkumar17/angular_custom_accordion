import { Component, AfterContentInit, ContentChild } from '@angular/core';

import { AccordionHeader } from './accordion-header';
import { AccordionContent } from './accordion-content';


@Component({
  selector: 'accordion-container',
  styleUrls: ['accordion.css'],
  template: `
    <div class="container table-border">
    <div class="row accordion-seperation row-hover">
      <ng-content></ng-content>
    </div>
    </div>
  `
})


export class AccordionContainer implements AfterContentInit {

  @ContentChild(AccordionHeader) header: AccordionHeader;
  @ContentChild(AccordionContent) content: AccordionContent;

  ngAfterContentInit() {
    this.header.openChange.subscribe(openState =>
      this.content.open = openState);
  }
}
